package dev.flutter.flutter_api_samples

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
